<?php
$options = array();

$options[] = array(
	'id'          => '_sh_layout_settings',
	'types'       => array('post', 'page', 'product', 'sh_services', 'sh_courses', ),
	'title'       => __('Layout Settings', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => 
			array(
					
					array(
						'type' => 'radioimage',
						'name' => 'layout',
						'label' => __('Page Layout', 'theme_support_hash'),
						'description' => __('Choose the layout for blog pages', 'theme_support_hash'),
						'items' => array(
							array(
								'value' => 'left',
								'label' => __('Left Sidebar', 'theme_support_hash'),
								'img' => SH_TH_URL.'/includes/vafpress/public/img/2cl.png',
							),
							array(
								'value' => 'right',
								'label' => __('Right Sidebar', 'theme_support_hash'),
								'img' => SH_TH_URL.'/includes/vafpress/public/img/2cr.png',
							),
							array(
								'value' => 'full',
								'label' => __('Full Width', 'theme_support_hash'),
								'img' => SH_TH_URL.'/includes/vafpress/public/img/1col.png',
							),
							
						),
					),
					
/*					array(
						'type' => 'select',
						'name' => 'sidebar',
						'label' => __('Sidebar', 'theme_support_hash'),
						'default' => '',
						'items' => sh_get_sidebars(true)	
					),*/
				),
);
$options[] = array(
	'id'          => '_sh_header_settings',
	'types'       => array('post', 'page', 'product', 'sh_portfolio', 'sh_courses',),
	'title'       => __('Header Settings', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => 
			array(
					
					
					array(
						'type' => 'upload',
						'name' => 'bg_image',
						'label' => __('Header Background Image', 'theme_support_hash'),
						'description' => __('Choose the header background image', 'theme_support_hash'),
					),
					array(
						'type' => 'textbox',
						'name' => 'header_title',
						'label' => __('Header Title', 'theme_support_hash'),
						'description' => __('Enter header title', 'theme_support_hash'),
					),
					array(
						'type' => 'notebox',
						'name' => 'nb_2',
						'label' => __('Info ', 'theme_support_hash'),
						'description' => __('Below option will only work on pages and VC page template', 'theme_support_hash'),
						'status' => 'info',
					),
					array(
						'type' => 'toggle',
						'name' => 'bread_crumb',
						'label' => __('Show/Hide breadcrumb on VC page', 'theme_support_hash'),
						'description' => __('Only work with VC Page template', 'theme_support_hash'),
					),
				),
);
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('post'),
	'types'       => array('post'),
	'title'       => __('Post Settings', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => 
			array(		
					array(
						'type' => 'toggle',
						'name' => 'top_posts',
						'label' => __('Show/Hide top posts', 'theme_support_hash'),
						'description' => __('Enable / disable seo Top post', 'theme_support_hash'),
					),
					array(
							 'type'      => 'group',
							 'repeating' => true,
							 'length'    => 1,
							 'name'      => 'sh_gallery_imgs',
							 'title'     => __('Gallery images', 'theme_support_hash'),
							 'fields'    => array(
								array(
							   'type' => 'upload',
							   'name' => 'gallery_image',
							   'label' => __('Gallery Image', 'theme_support_hash'),
							   'description' => __('Choose the Gallery images', 'theme_support_hash'),
							  ),
							 ),
							), 
					array(
						'type' => 'textarea',
						'name' => 'video',
						'label' => __('Video Embed Code', 'theme_support_hash'),
						'default' => '',
						'description' => __('If post format is video then this embed code will be used in content', 'theme_support_hash')
					),
					array(
						'type' => 'textarea',
						'name' => 'audio',
						'label' => __('Audio Embed Code', 'theme_support_hash'),
						'default' => '',
						'description' => __('If post format is AUDIO then this embed code will be used in content', 'theme_support_hash')
					),
					array(
						'type' => 'textarea',
						'name' => 'quote',
						'label' => __('Quote', 'theme_support_hash'),
						'default' => '',
						'description' => __('If post format is quote then the content in this textarea will be displayed', 'theme_support_hash')
					),
							
					
			),
);
/* Page options */
/** Team Options*/
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_team'),
	'types'       => array('sh_team'),
	'title'       => __('Team Options', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
	
						
				array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', 'theme_support_hash'),
					'default' => '',
				),
/*				array(
					'type' => 'textbox',
					'name' => 'experience',
					'label' => __('Experience', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textarea',
					'name' => 'professional',
					'label' => __('Professional', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textarea',
					'name' => 'skills',
					'label' => __('Skills', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textarea',
					'name' => 'references',
					'label' => __('References', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'phone',
					'label' => __('Phone', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'email',
					'label' => __('Email', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textarea',
					'name' => 'team_shortcodes',
					'label' => __('Shortcodes', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type'  => 'upload',
					'name'  => 'team_image',
					'label' => __('Detail Page Image', 'theme_support_hash'),
				),*/
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'sh_team_social',
					'title'     => __('Social Profile', 'theme_support_hash'),
					'fields'    => array(
						
						array(
							'type' => 'fontawesome',
							'name' => 'social_icon',
							'label' => __('Social Icon', 'theme_support_hash'),
							'default' => '',
						),
						
						array(
							'type' => 'textbox',
							'name' => 'social_link',
							'label' => __('Link', 'theme_support_hash'),
							'default' => '',
							
						),
						
						
					),
				),
	),
);
/** Causes Options*/
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_causes'),
	'types'       => array('sh_causes'),
	'title'       => __('Causes Options', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'num',
					'label' => __('% Number', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'cause_affected',
					'label' => __('Cause Affected', 'theme_support_hash'),
					'default' => 'For 29 Families',
				),
				array(
					'type' => 'textbox',
					'name' => 'readlink',
					'label' => __('Readmore Link', 'theme_support_hash'),
					'default' => '#',
				),
				array(
					'type' => 'upload',
					'name' => 'large_image',
					'label' => __('Large Image', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textarea',
					'name' => 'causes_shortcodes',
					'label' => __('Shortcodes', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'select',
					'name' => 'give_form',
					'label' => __('Give Donation Form', 'theme_support_hash'),
					'description' => __('Choose the give donation form', 'theme_support_hash'),
					'items' => array(
						'data' => array(
							array(
								'source' => 'function',
								'value' => 'vp_get_posts',
								'params' => 'give_forms'
							),
						),
					),
				),
	),
);
/** Donate Options*/
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_donate'),
	'types'       => array('sh_donate'),
	'title'       => __('Donate Options', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'donation',
					'label' => __('Donation amount', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'target',
					'label' => __('Target Donation', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'collected',
					'label' => __('Collected Donation', 'theme_support_hash'),
					'default' => '',
				),
				
	),
);

/** Donors Options*/
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_donors'),
	'types'       => array('sh_donors'),
	'title'       => __('Donors Options', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
				
				array(
					'type' => 'textbox',
					'name' => 'company',
					'label' => __('Donor Company', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type'  => 'upload',
					'name'  => 'image',
					'label' => __('Background Image', 'theme_support_hash'),
				),
				array(
					'type' => 'textbox',
					'name' => 'ext_url',
					'label' => __('External Url', 'theme_support_hash'),
					'default' => '',
				),
				
				
	),
);

/** Testimonial Options*/
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_testimonials'),
	'types'       => array('sh_testimonials'),
	'title'       => __('Testimonials Options', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'company',
					'label' => __('Company', 'theme_support_hash'),
					'default' => 'Envato',
				)
	),
);
/** Projects Options*/
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_portfolio'),
	'types'       => array('sh_portfolio'),
	'title'       => __('Projects Options', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
						array(
							'type' => 'select',
							'name' => 'give_form',
							'label' => __('Give Donation Form', 'theme_support_hash'),
							'description' => __('Choose the give donation form', 'theme_support_hash'),
							'items' => array(
								'data' => array(
									array(
										'source' => 'function',
										'value' => 'vp_get_posts',
										'params' => 'give_forms'
									),
								),
							),
						),
						array(
							'type' => 'textbox',
							'name' => 'video_webm',
							'label' => __('video webm Link', 'theme_support_hash'),
							'description' => __('video webm Link', 'theme_support_hash'),
						),
						array(
							'type' => 'textbox',
							'name' => 'video_ogg',
							'label' => __('video ogg Link', 'theme_support_hash'),
							'description' => __('video ogg Link', 'theme_support_hash'),
						),
						array(
							'type' => 'textbox',
							'name' => 'video_mp4',
							'label' => __('video mp4 Link', 'theme_support_hash'),
							'description' => __('video mp4 Link', 'theme_support_hash'),
						),
						array(
							'type' => 'textbox',
							'name' => 'video_3gp',
							'label' => __('video 3gp Link', 'theme_support_hash'),
							'description' => __('video 3gp Link', 'theme_support_hash'),
						),

						array(
							'type' => 'textarea',
							'name' => 'portfolio_shortcodes',
							'label' => __('Shortcodes', 'theme_support_hash'),
							'default' => '',
						),
					
				 
									
	),
);
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_gallery'),
	'types'       => array('sh_gallery'),
	'title'       => __('Image Gallery Settings', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textarea',
					'name' => 'gallery_shortcodes',
					'label' => __('Shortcodes', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'sortable'  => true,
					'name'      => 'column',
					'title'     => __('Images', 'theme_support_hash'),
					'fields'    => array(
						array(
							'type'  => 'textbox',
							'name'  => 'image_title',
							'label' => __('Title', 'theme_support_hash'),
						),
						array(
							'type'                       => 'upload',
							'label'                      => __('Image', 'theme_support_hash'),
							'name'                       => 'image',
							'use_external_plugins'       => 1,
							'validation'                 => 'required',
						),
						array(
							'type'  => 'textarea',
							'name'  => 'image_description',
							'label' => __('Description', 'theme_support_hash'),
						),
						
					),
				
		),
	),
);
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_services'),
	'types'       => array( 'sh_services' ),
	'title'       => __('Services Settings', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => 
			array(
				array(
					'type' => 'upload',
					'name' => 'service_image',
					'label' => __('Services Image', 'theme_support_hash'),
					'description' => __('Add Another image to services', 'theme_support_hash'),
				),
			    
				array(
					'type' => 'textbox',
					'name' => 'single_link',
					'label' => __('Read More Link', 'theme_support_hash'),
					'description' => __('Enter the URL to redirect user for further reading', 'theme_support_hash'),
				),
			),
);
//timetable
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_timetable'),
	'types'       => array( 'sh_timetable' ),
	'title'       => __('timetable Settings', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => 
			array(
				array(
					'type' => 'textbox',
					'name' => 'lesson_start_time',
					'label' => __('Lesson Start time', 'theme_support_hash'),
					'description' => __('Enter the Lesson Start time', 'theme_support_hash'),
				),
				array(
					'type' => 'textbox',
					'name' => 'lesson_end_time',
					'label' => __('Lesson End time', 'theme_support_hash'),
					'description' => __('Enter the Lesson End time', 'theme_support_hash'),
				),
				array(
					'type' => 'select',
					'name' => 'sorting_courses',
					'label' => __('Choose Courses', 'theme_support_hash'),
					'description' => __('Choose Courses', 'theme_support_hash'),
					'items' => array(
						'data' => array(
							array(
								'source' => 'function',
								'value' => 'vp_get_courses',
							),
						),
					),
				),
			),
);

/** Course Options*/
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_courses'),
	'types'       => array('sh_courses'),
	'title'       => __('Courses Options', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'course_fee',
					'label' => __('Course Fee', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'course_duration',
					'label' => __('Course Duration', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'old_course_fee',
					'label' => __('Old Course Fee', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'course_type',
					'label' => __('Course Type', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'course_start_date',
					'label' => __('Course Start Date', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'course_end_date',
					'label' => __('Course End Date', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'course_place',
					'label' => __('Course Place', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'course_seat',
					'label' => __('Course Seat', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textarea',
					'name' => 'feature_description',
					'label' => __('Feature Description', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'textarea',
					'name' => 'features',
					'label' => __('Please add features 1 per line', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'sorter',
					'name' => 'sorting_members',
					'label' => __('Choose Members', 'theme_support_hash'),
					'description' => __('Choose Members to list in column', 'theme_support_hash'),
					'items' => array(
						'data' => array(
							array(
								'source' => 'function',
								'value' => 'vp_get_users',
							),
						),
					),
				),
				
	),
);
/** Causes Options*/
$options[] =  array(
	'id'          => HASH_WSH()->set_meta_key('sh_sponsor'),
	'types'       => array('sh_sponsor'),
	'title'       => __('Sponsor Options', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'subtitle',
					'label' => __('Subtitle', 'theme_support_hash'),
					'default' => '',
				),
				array(
					'type' => 'select',
					'name' => 'gender',
					'label' => __('Gender', 'theme_support_hash'),
					'default' => '',
					'items' => array(
									array(
										'value' => 'Male',
										'label' => __('Male', 'theme_support_hash'),
									),
									array(
										'value' => 'Female',
										'label' => __('Female', 'theme_support_hash'),
									),
									array(
										'value' => 'Other',
										'label' => __('Other', 'theme_support_hash'),
									),
								),
					),
				array(
					'type' => 'select',
					'name' => 'country',
					'label' => __('Country', 'theme_support_hash'),
					'default' => '',
					'items' => array(
									array(
										'value' => 'USA',
										'label' => __('USA', 'theme_support_hash'),
									),
									array(
										'value' => 'UK',
										'label' => __('UK', 'theme_support_hash'),
									),
									array(
										'value' => 'UAE',
										'label' => __('UAE', 'theme_support_hash'),
									),
								),
					),
				array(
					'type' => 'select',
					'name' => 'age',
					'label' => __('Age', 'theme_support_hash'),
					'default' => '',
					'items' => array(
									array(
										'value' => '10',
										'label' => __('10', 'theme_support_hash'),
									),
									array(
										'value' => '20',
										'label' => __('20', 'theme_support_hash'),
									),
									array(
										'value' => '30',
										'label' => __('30', 'theme_support_hash'),
									),
								),
					),
				array(
					'type' => 'date',
					'name' => 'dob',
					'label' => __('DOB', 'theme_support_hash'),
					'default' => '',
				),		
	),
);

//------------------------foogallery-------------
$options[] =  array(
	'id'          => '_sh_custom_metabox',
	'types'       => array('foogallery'),
	'title'       => __('Gallery Options', 'theme_support_hash'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textarea',
					'name' => 'gallery_shortcodes',
					'label' => __('Gallery Shortcods', 'theme_support_hash'),
					'default' => '',
				),
	),
);


/**
 * EOF
 */
 
 
return $options;