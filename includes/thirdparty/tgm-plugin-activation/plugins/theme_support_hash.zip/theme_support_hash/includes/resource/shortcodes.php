<?php
$sh_sc =array();
$animations = array(
				array(
				   "type" => "dropdown",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __('Animation', SH_NAME ),
				   "param_name" => "animation",
				   "value" => hash_wow_themes_animation(),
				   "description" => __('Choose animation style for this section.', SH_NAME ),
				   'group' => __( 'Animations', SH_NAME ),
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __('Speed', SH_NAME ),
				   "param_name" => "anim_speed",
				   "value" => '',
				   "description" => __('Enter the animation speed in seconds.', SH_NAME ),
				   'group' => __( 'Animations', SH_NAME ),
				   //"dependency" => Array('element' => "animation", 'value' => hash_wow_themes_animation()),
				),
	);
$sh_sc['sh_post_vertical']	=	array(
					"name" => __("Post Vertical", 'theme_support_hash'),
					"base" => "sh_post_vertical",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the posts.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', 'theme_support_hash' )
						),
		                                	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Tag Text', 'theme_support_hash' ),
						   "param_name" => "tagline",
						   "description" => __('Enter Tag Text.', 'theme_support_hash' )
						),
							array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Tag URL', 'theme_support_hash' ),
						   "param_name" => "tagurl",
						   "description" => __('Enter Tag URL.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'), 'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'ASC'=>__( 'Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Extra Class', 'theme_support_hash' ),
						   "param_name" => "extra_class",
						   "description" => __('Enter Extra Class.', 'theme_support_hash' )
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Style 2', 'theme_support_hash' ),
						   "param_name" => "style2",
						   //"value" => array(esc_html__('Style 2', 'theme_support_hash') => 'style2'),
						   "description" => __('Enter Extra Class.', 'theme_support_hash' )
						),
						$animations[0],
						$animations[1]
					)
				);
				
$sh_sc['sh_post_squared']	=	array(
					"name" => __("Post Squard", 'theme_support_hash'),
					"base" => "sh_post_squared",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the posts.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', 'theme_support_hash' )
						),
		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'), 'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'ASC'=>__('Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						$animations[0],
						$animations[1]
					)
				);
				
$sh_sc['sh_post_side_post']	=	array(
					"name" => __("posts with side post", 'theme_support_hash'),
					"base" => "sh_post_side_post",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the posts.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', 'theme_support_hash' )
						),
						array(
						   "type" => "colorpicker",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Backgroud Color', 'theme_support_hash' ),
						   "param_name" => "color",
						   "value" => array_flip(  array( 'true' => 'colorful', 'false' =>'None' ) ),
						   "description" => __( 'Choose background color left empty if you choosed the background image.', 'theme_support_hash' )
				  ),
				  		array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", 'theme_support_hash'),
						   "param_name" => "image",
						   'value' => '',
						   "description" => __("Enter the Image url", 'theme_support_hash')
				  ),
		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'), 'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'ASC'=>__('Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Select Style", 'theme_support_hash'),
						   "param_name" => "style",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'style1'=>__('Big Image on Left', 'theme_support_hash'),'style2'=>__('Big Image on Right', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Doted image", SH_NAME),
						   "param_name" => "doted_img",
						   'value' => array_flip( array( ''=>__('SELECT', SH_NAME), 'vertical'=>__('Vertical Doted', SH_NAME),'horizental'=>__('Horizental Doted', SH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", SH_NAME)
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Show Pagination", 'theme_support_hash'),
						   "param_name" => "pagination",
						   'value' => array(__('Show Pagination', 'theme_support_hash')=>1),
						   "description" => __("Show Pagination", 'theme_support_hash')
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Show Title", 'theme_support_hash'),
						   "param_name" => "show_title",
						   'value' => array(__('Show Title', 'theme_support_hash')=>1),
						   "description" => __("Show Category Title", 'theme_support_hash')
						),
						$animations[0],
						$animations[1]
					)
				);
				
$sh_sc['sh_post_side_post2'] =	array(
					"name" => __("posts with side post 2", 'theme_support_hash'),
					"base" => "sh_post_side_post2",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the posts.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', 'theme_support_hash' )
						),
						array(
						   "type" => "colorpicker",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Backgroud Color', 'theme_support_hash' ),
						   "param_name" => "color",
						   "value" => array_flip(  array( 'true' => 'colorful', 'false' =>'None' ) ),
						   "description" => __( 'Choose background color left empty if you choosed the background image.', 'theme_support_hash' )
				  ),
				  		array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", 'theme_support_hash'),
						   "param_name" => "image",
						   'value' => '',
						   "description" => __("Enter the Image url", 'theme_support_hash')
				  ),
		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'), 'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'),'ASC'=>__('Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Select Style", 'theme_support_hash'),
						   "param_name" => "style",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'style1'=>__('Big Image on Left', 'theme_support_hash'),'style2'=>__('Big Image on Right', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Show Pagination", 'theme_support_hash'),
						   "param_name" => "pagination",
						   'value' => array(__('Show Pagination', 'theme_support_hash')=>1),
						   "description" => __("Show Pagination", 'theme_support_hash')
						),
						$animations[0],
						$animations[1]
					)
				);
				
$sh_sc['sh_post_top_post']	=	array(
					"name" => __("posts with top post", 'theme_support_hash'),
					"base" => "sh_post_top_post",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the posts.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', 'theme_support_hash' )
						),
						
						array(
						   "type" => "colorpicker",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Color', 'theme_support_hash' ),
						   "param_name" => "color",
						   "value" => array_flip(  array( 'true' => 'colorful', 'false' =>'None' ) ),
						   "description" => __( 'Choose Category Color Shown in description.', 'theme_support_hash' )
				  ),		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'), 'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'ASC'=>__('Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Show Icon", SH_NAME),
						   "param_name" => "show_icon",
						   'value' => array(__('Show Video Icon', SH_NAME)=>1),
						   "description" => __("Show Video Play Icon.", SH_NAME)
						),	
						$animations[0],
						$animations[1]
					)
				);

$sh_sc['sh_post_top_post_1']	=	array(
					"name" => __("Posts with Top Post ( Video )", 'theme_support_hash'),
					"base" => "sh_post_top_post_1",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the posts.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', 'theme_support_hash' )
						),
						
						array(
						   "type" => "colorpicker",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Color', 'theme_support_hash' ),
						   "param_name" => "color",
						   "value" => array_flip(  array( 'true' => 'colorful', 'false' =>'None' ) ),
						   "description" => __( 'Choose Category Color Shown in description.', 'theme_support_hash' )
				  ),		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'), 'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'ASC'=>__('Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						$animations[0],
						$animations[1]
					)
				);


$sh_sc['sh_latest_news']	=	array(
					"name" => __("Latest News ticker", 'theme_support_hash'),
					"base" => "sh_latest_news",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the latest news ticker.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_hash' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_hash' )
						),
						$animations[0],
						$animations[1]
					)
				);
				
$sh_sc['sh_top_social']	=	array(
					"name" => __("Top Bar Social Icons", 'theme_support_hash'),
					"base" => "sh_top_social",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the posts.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_hash' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_hash' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Causes to Show.', 'theme_support_hash' )
						),
		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'causes_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'), 'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'ASC'=>__('Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						$animations[0],
						$animations[1]
					)
				);

$sh_sc['sh_what_we_are']	=	array(
					"name" => __("What We Are", 'theme_support_hash'),
					"base" => "sh_what_we_are",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('What are we doing.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_hash' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_hash' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button 1 Text', 'theme_support_hash' ),
						   "param_name" => "btn1_text",
						   "description" => __('Button one Text.', 'theme_support_hash' )
						),
		
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button 1 URL', 'theme_support_hash' ),
						   "param_name" => "btn1_link",
						   "description" => __('Button one link.', 'theme_support_hash' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button 2 Text', 'theme_support_hash' ),
						   "param_name" => "btn2_text",
						   "description" => __('Button two Text.', 'theme_support_hash' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button 2 URL', 'theme_support_hash' ),
						   "param_name" => "btn2_link",
						   "description" => __('Button two URL, write with http://.', 'theme_support_hash' )
						),
						
						array(
						   "type" => "attach_images",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Slider Images', 'theme_support_hash' ),
						   "param_name" => "images",
						   "description" => __( 'Choose images for slider.', 'theme_support_hash' )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Content', 'theme_support_hash' ),
						   "param_name" => "content",
						   "description" => __( 'Enter content, you can use html tags.', 'theme_support_hash' )
						),
						$animations[0],
						$animations[1]
					)
				);



				
$sh_sc['sh_upload_add'] = array(
			"name" => __("Upload Add Here", 'theme_support_hash'),
			"base" => "sh_upload_add",
			"class" => "",
			"category" => __('Hash', 'theme_support_hash'),
			"icon" => 'fa-user' ,
			'description' => __('Upload Add From Here.', 'theme_support_hash'),
			"params" => array(
				    array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", 'theme_support_hash'),
						   "param_name" => "image",
						   'value' => '',
						   "description" => __("Enter the Image url", 'theme_support_hash')
				  ),
				  	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('URL', 'theme_support_hash' ),
						   "param_name" => "url",
						   "description" => __('Enter URL.', 'theme_support_hash' )
						),
				  		$animations[0],
						$animations[1]
				
            ));

$sh_sc['sh_post_top_post_section'] = array(
   "name" => __("Post Top Post Section", 'theme_support_hash'),
   "base" => "sh_post_top_post_section",
   "class" => "",
   "category" => __('Hash', 'theme_support_hash'),
   "icon" => 'icon-wpb-layer-shape-text' ,
   "as_parent" => array('only' => 'sh_post_top_post'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
   "content_element" => true,
   "show_settings_on_create" => false,
   'description' => __('Add Number Posts.', 'theme_support_hash'),
   "params" => array(
				array(
				   "type" => "colorpicker",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __( 'Backgroud Color', 'theme_support_hash' ),
				   "param_name" => "color",
				   "value" => array_flip(  array( 'true' => 'colorful', 'false' =>'None' ) ),
				   "description" => __( 'Choose background color left empty if you choosed the background image.', 'theme_support_hash' )
		  ),
				array(
				   "type" => "attach_image",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Image", 'theme_support_hash'),
				   "param_name" => "image",
				   'value' => '',
				   "description" => __("Enter the Image url", 'theme_support_hash')
		  ),
				array(
					   "type" => "dropdown",
					   "holder" => "div",
					   "class" => "",
					   "heading" => __( 'Category', 'theme_support_hash' ),
					   "param_name" => "cat",
					   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
					   "description" => __( 'Choose Category.', 'theme_support_hash' )
					),
					$animations[0],
					$animations[1]
   ),
   "js_view" => 'VcColumnView'
  );
  
$sh_sc['sh_posts_top_post'] = array(
   "name" => __("Posts Top Posts", 'theme_support_hash'),
   "base" => "sh_posts_top_post",
   "class" => "",
   "category" => __('Hash', 'theme_support_hash'),
   "icon" => 'icon-wpb-layer-shape-text' ,
   "as_child" => array('only' => 'sh_post_top_post_section'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
   "content_element" => true,
   "show_settings_on_create" => true,
   'description' => __('Add Posts.', 'theme_support_hash'),
   "params" => array(
array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', 'theme_support_hash' )
						),
						
						array(
						   "type" => "colorpicker",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Backgroud Color', 'theme_support_hash' ),
						   "param_name" => "color",
						   "value" => array_flip(  array( 'true' => 'colorful', 'false' =>'None' ) ),
						   "description" => __( 'Choose background color left empty if you choosed the background image.', 'theme_support_hash' )
				  ),		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'), 'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'ASC'=>__('Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
   ),
  );
  
$sh_sc['sh_skills_section'] = array(
   "name" => __("Skills", 'theme_support_hash'),
   "base" => "sh_skills_section",
   "class" => "",
   "category" => __('Hash', 'theme_support_hash'),
   "icon" => 'icon-wpb-layer-shape-text' ,
   "as_parent" => array('only' => 'sh_skills'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
   "content_element" => true,
   "show_settings_on_create" => false,
   'description' => __('Add Number Posts.', 'theme_support_hash'),
   "params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", 'theme_support_hash'),
				   "param_name" => "title",
				   'value' => '',
				   "description" => __("Enter the Title", 'theme_support_hash')
				),
				$animations[0],
				$animations[1]
   ),
   "js_view" => 'VcColumnView'
  );
  
$sh_sc['sh_skills'] = array(
   "name" => __("Add Skill", 'theme_support_hash'),
   "base" => "sh_skills",
   "class" => "",
   "category" => __('Hash', 'theme_support_hash'),
   "icon" => 'icon-wpb-layer-shape-text' ,
   "as_child" => array('only' => 'sh_skills_section'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
   "content_element" => true,
   "show_settings_on_create" => true,
   'description' => __('Add Posts.', 'theme_support_hash'),
   "params" => array(
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Skill', 'theme_support_hash' ),
						   "param_name" => "skill",
						   "description" => __('Enter Skill.', 'theme_support_hash' )
						),
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', 'theme_support_hash' ),
						   "param_name" => "percentage",
						   "description" => __('Enter Percentage without sign.', 'theme_support_hash' )
						),
					$animations[0],
					$animations[1]
   ),
  );
  
$sh_sc['sh_accordian']	=	array(
					"name" => __("Accordian", 'theme_support_hash'),
					"base" => "sh_accordian",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show accordian of the posts.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Author', 'theme_support_hash' ),
						   "param_name" => "auth",
						   "description" => __('Enter author name of post to Show.', 'theme_support_hash' )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', 'theme_support_hash' ),
						   "param_name" => "text",
						   "description" => __('Enter text of post to Show.', 'theme_support_hash' )
						),
						array(
        				   "type" => "attach_image",
        				   "holder" => "div",
        				   "class" => "",
        				   "heading" => __("Image", 'theme_support_hash'),
        				   "param_name" => "image",
        				   'value' => '',
        				   "description" => __("Enter the Image url", 'theme_support_hash')
        		        ),
						$animations[0],
						$animations[1]
					)
				);
  
$sh_sc['sh_post_squared_large']	=	array(
					"name" => __("Post Squard Large", 'theme_support_hash'),
					"base" => "sh_post_squared_large",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the posts.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', 'theme_support_hash' )
						),
		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'), 'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'), 'ASC'=>__('Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash')
						),
						$animations[0],
						$animations[1]
					)
				);	
				
$sh_sc['sh_map'] = array(
			"name" => __("Google map", 'theme_support_hash'),
			"base" => "sh_map",
			"class" => "",
			"category" => __('Hash', 'theme_support_hash'),
			"icon" => 'fa-user' ,
			'description' => __('show the google map.', 'theme_support_hash'),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Lattitude", 'theme_support_hash'),
				   "param_name" => "lat",
				   'value' => '',
				   "description" => __("Enter the lattitude", 'theme_support_hash')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Longitude", 'theme_support_hash'),
				   "param_name" => "long",
				   'value' => '',
				   "description" => __("Enter the Longitude", 'theme_support_hash')
				),
			)
	    );
		
$sh_sc['sh_contact_info']	=	array(
					"name" => __("Contact Information", 'theme_support_hash'),
					"base" => "sh_contact_info",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-envelope-o' ,
					'description' => __('Show the contact Information', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_hash' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_hash' )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Description', 'theme_support_hash' ),
						   "param_name" => "description",
						   "description" => __('Enter the Description', 'theme_support_hash' )
						),
						 array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Address', 'theme_support_hash' ),
						   "param_name" => "address",
						   "description" => __('Enter the address', 'theme_support_hash' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Phone', 'theme_support_hash' ),
						   "param_name" => "phone",
						   "description" => __('Enter the phone', 'theme_support_hash' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Email', 'theme_support_hash' ),
						   "param_name" => "email",
						   "description" => __('Enter the email', 'theme_support_hash' )
						),
						$animations[0],
						$animations[1]
					)
				);	

$sh_sc['sh_team']	=	array(
					"name" => __("Team", 'theme_support_hash'),
					"base" => "sh_team",
					"class" => "",
					"category" => __('Hash', 'theme_support_hash'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Teams.', 'theme_support_hash'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_hash' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_hash' ),
						   "value" => "",
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_hash' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_hash' ),
						   "value" => "",
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_hash' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)hash_wow_themes_get_categories( array( 'taxonomy' => 'team_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_hash' ),
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_hash'),
						   "param_name" => "sort",
						   'value' => array_flip( array( ''=>__('SELECT', 'theme_support_hash'),'date'=>__('Date', 'theme_support_hash'),'title'=>__('Title', 'theme_support_hash') ,'name'=>__('Name', 'theme_support_hash') ,'author'=>__('Author', 'theme_support_hash'),'comment_count' =>__('Comment Count', 'theme_support_hash'),'random' =>__('Random', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash'),
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_hash'),
						   "param_name" => "order",
						   'value' => array_flip(array( ''=>__('SELECT', 'theme_support_hash'),'ASC'=>__('Ascending', 'theme_support_hash'),'DESC'=>__('Descending', 'theme_support_hash') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_hash'),
						),
						$animations[0],
						$animations[1]
					)
				);
/*----------------------------------------------------------------------------*/
$sh_sc = apply_filters( '_sh_shortcodes_array', $sh_sc );
	
return $sh_sc;