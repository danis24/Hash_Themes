<?php
class SH_Taxonomies
{
	
	var $team_slug = '' ;
	var $services_slug = '' ;
	var $portfolio_slug = '' ;
	var $gallery_slug = '' ;
	var $causes_slug = '' ;
	var $donate_slug = '' ;
	var $donors_slug = '' ;
	var $sponsor_slug = '' ;
	var $team_cat_slug = '';
	var $services_cat_slug = '' ;
	var $portfolio_cat_slug = '' ;
	var $gallery_cat_slug = '' ;
	var $causes_cat_slug = '' ;
	var $donate_cat_slug = '' ;
	var $donors_cat_slug = '' ;
	var $sponsor_cat_slug = '' ;
	var $donors_type_cat_slug = '';
	
	
	function __construct()
	{
		// Hook into the 'init' action
		//add_action( 'init', array($this, 'taxonomies'), 0 );
		$theme_option = HASH_WSH()->option() ; 
		$this->team_cat_slug = hash_wow_sh_set($theme_option , 'team_category_permalink' , 'team_category') ;
		$this->services_cat_slug = hash_wow_sh_set($theme_option , 'services_category_permalink' , 'services_category') ;
		$this->portfolio_cat_slug = hash_wow_sh_set($theme_option , 'portfolio_category_permalink' , 'portfolio_category');
		$this->gallery_cat_slug = hash_wow_sh_set($theme_option , 'gallery_category_permalink' , 'gallery_category') ;
		$this->causes_cat_slug = hash_wow_sh_set($theme_option , 'causes_category_permalink' , 'causes_category');
		$this->donate_cat_slug = hash_wow_sh_set($theme_option , 'donate_category_permalink' , 'donate_category') ;
		$this->donors_cat_slug = hash_wow_sh_set($theme_option , 'donors_category_permalink' , 'donors_category') ;
		$this->sponsor_cat_slug = hash_wow_sh_set($theme_option , 'sponsor_category_permalink' , 'sponsor_category') ;
		$this->donors_type_cat_slug = hash_wow_sh_set($theme_option , 'donors_type_category_permalink' , 'donors_type_category') ;
		$this->taxonomies();
	}
	
	// Register Custom Taxonomy
	function taxonomies()  {
		
		$labels = array(
			'name'                       => _x( 'Category', 'Team Category', SH_NAME ),
			'singular_name'              => _x( 'Category', 'Category', SH_NAME ),
			'menu_name'                  => __( 'Category', 'theme_support_hash' ),
			'all_items'                  => __( 'All Categories', 'theme_support_hash' ),
			'parent_item'                => __( 'Parent Category', 'theme_support_hash' ),
			'parent_item_colon'          => __( 'Parent Category:', 'theme_support_hash' ),
			'new_item_name'              => __( 'New Category Name', 'theme_support_hash' ),
			'add_new_item'               => __( 'Add New Category', 'theme_support_hash' ),
			'edit_item'                  => __( 'Edit Category', 'theme_support_hash' ),
			'update_item'                => __( 'Update Category', 'theme_support_hash' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'theme_support_hash' ),
			'search_items'               => __( 'Search Categories', 'theme_support_hash' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'theme_support_hash' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'theme_support_hash' ),
		);
	
		$rewrite = array(
			'slug'                       => $this->team_cat_slug,
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy( 'team_category', 'sh_team', $args );
		
		
		$labels = array(
			'name'                       => _x( 'Category', 'Gallery Category', SH_NAME ),
			'singular_name'              => _x( 'Category', 'Category', SH_NAME ),
			'menu_name'                  => __( 'Category', 'theme_support_hash' ),
			'all_items'                  => __( 'All Categories', 'theme_support_hash' ),
			'parent_item'                => __( 'Gallery Category', 'theme_support_hash' ),
			'parent_item_colon'          => __( 'Gallery Category:', 'theme_support_hash' ),
			'new_item_name'              => __( 'New Category Name', 'theme_support_hash' ),
			'add_new_item'               => __( 'Add New Category', 'theme_support_hash' ),
			'edit_item'                  => __( 'Edit Category', 'theme_support_hash' ),
			'update_item'                => __( 'Update Category', 'theme_support_hash' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'theme_support_hash' ),
			'search_items'               => __( 'Search Categories', 'theme_support_hash' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'theme_support_hash' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'theme_support_hash' ),
		);
	
		$rewrite = array(
			'slug'                       => $this->gallery_cat_slug,
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy( 'gallery_category', 'sh_gallery', $args );
		
		
		$labels = array(
			'name'                       => _x( 'Category', 'Service Category', SH_NAME ),
			'singular_name'              => _x( 'Category', 'Category', SH_NAME ),
			'menu_name'                  => __( 'Category', 'theme_support_hash' ),
			'all_items'                  => __( 'All Categories', 'theme_support_hash' ),
			'parent_item'                => __( 'Parent Category', 'theme_support_hash' ),
			'parent_item_colon'          => __( 'Parent Category:', 'theme_support_hash' ),
			'new_item_name'              => __( 'New Category Name', 'theme_support_hash' ),
			'add_new_item'               => __( 'Add New Category', 'theme_support_hash' ),
			'edit_item'                  => __( 'Edit Category', 'theme_support_hash' ),
			'update_item'                => __( 'Update Category', 'theme_support_hash' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'theme_support_hash' ),
			'search_items'               => __( 'Search Categories', 'theme_support_hash' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'theme_support_hash' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'theme_support_hash' ),
		);
	
		$rewrite = array(
			'slug'                       => $this->services_cat_slug,
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy('services_category', 'sh_services', $args );
		
		/*** Register faqs taxonomy portfolio_category */
		
		
		$labels = array(
			'name'                       => _x( 'Category', 'Portfolio Category', SH_NAME ),
			'singular_name'              => _x( 'Category', 'Category', SH_NAME ),
			'menu_name'                  => __( 'Category', 'theme_support_hash' ),
			'all_items'                  => __( 'All Categories', 'theme_support_hash' ),
			'parent_item'                => __( 'Parent Category', 'theme_support_hash' ),
			'parent_item_colon'          => __( 'Parent Category:', 'theme_support_hash' ),
			'new_item_name'              => __( 'New Category Name', 'theme_support_hash' ),
			'add_new_item'               => __( 'Add New Category', 'theme_support_hash' ),
			'edit_item'                  => __( 'Edit Category', 'theme_support_hash' ),
			'update_item'                => __( 'Update Category', 'theme_support_hash' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'theme_support_hash' ),
			'search_items'               => __( 'Search Categories', 'theme_support_hash' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'theme_support_hash' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'theme_support_hash' ),
		);
	
		$rewrite = array(
			'slug'                       => $this->portfolio_cat_slug,
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy('portfolio_category', 'sh_portfolio', $args );
		
		$labels = array(
			'name'                       => _x( 'Category', 'Causes Category', SH_NAME ),
			'singular_name'              => _x( 'Category', 'Category', SH_NAME ),
			'menu_name'                  => __( 'Category', 'theme_support_hash' ),
			'all_items'                  => __( 'All Categories', 'theme_support_hash' ),
			'parent_item'                => __( 'Parent Category', 'theme_support_hash' ),
			'parent_item_colon'          => __( 'Parent Category:', 'theme_support_hash' ),
			'new_item_name'              => __( 'New Category Name', 'theme_support_hash' ),
			'add_new_item'               => __( 'Add New Category', 'theme_support_hash' ),
			'edit_item'                  => __( 'Edit Category', 'theme_support_hash' ),
			'update_item'                => __( 'Update Category', 'theme_support_hash' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'theme_support_hash' ),
			'search_items'               => __( 'Search Categories', 'theme_support_hash' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'theme_support_hash' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'theme_support_hash' ),
		);
	
		$rewrite = array(
			'slug'                       => $this->causes_cat_slug,
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy('causes_category', 'sh_causes', $args );
		
		$labels = array(
			'name'                       => _x( 'Category', 'Donate Category', SH_NAME ),
			'singular_name'              => _x( 'Category', 'Category', SH_NAME ),
			'menu_name'                  => __( 'Category', 'theme_support_hash' ),
			'all_items'                  => __( 'All Categories', 'theme_support_hash' ),
			'parent_item'                => __( 'Parent Category', 'theme_support_hash' ),
			'parent_item_colon'          => __( 'Parent Category:', 'theme_support_hash' ),
			'new_item_name'              => __( 'New Category Name', 'theme_support_hash' ),
			'add_new_item'               => __( 'Add New Category', 'theme_support_hash' ),
			'edit_item'                  => __( 'Edit Category', 'theme_support_hash' ),
			'update_item'                => __( 'Update Category', 'theme_support_hash' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'theme_support_hash' ),
			'search_items'               => __( 'Search Categories', 'theme_support_hash' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'theme_support_hash' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'theme_support_hash' ),
		);
	
		$rewrite = array(
			'slug'                       => $this->donate_cat_slug,
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy('donate_category', 'sh_donate', $args );
		
		$labels = array(
			'name'                       => _x( 'Category', 'Donors Category', SH_NAME ),
			'singular_name'              => _x( 'Category', 'Category', SH_NAME ),
			'menu_name'                  => __( 'Category', 'theme_support_hash' ),
			'all_items'                  => __( 'All Categories', 'theme_support_hash' ),
			'parent_item'                => __( 'Parent Category', 'theme_support_hash' ),
			'parent_item_colon'          => __( 'Parent Category:', 'theme_support_hash' ),
			'new_item_name'              => __( 'New Category Name', 'theme_support_hash' ),
			'add_new_item'               => __( 'Add New Category', 'theme_support_hash' ),
			'edit_item'                  => __( 'Edit Category', 'theme_support_hash' ),
			'update_item'                => __( 'Update Category', 'theme_support_hash' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'theme_support_hash' ),
			'search_items'               => __( 'Search Categories', 'theme_support_hash' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'theme_support_hash' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'theme_support_hash' ),
		);
	
		$rewrite = array(
			'slug'                       => $this->donors_cat_slug,
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy('donors_category', 'sh_donors', $args );
		
		$labels = array(
			'name'                       => _x( 'Category', 'Sponsor Category', SH_NAME ),
			'singular_name'              => _x( 'Category', 'Category', SH_NAME ),
			'menu_name'                  => __( 'Category', 'theme_support_hash' ),
			'all_items'                  => __( 'All Categories', 'theme_support_hash' ),
			'parent_item'                => __( 'Parent Category', 'theme_support_hash' ),
			'parent_item_colon'          => __( 'Parent Category:', 'theme_support_hash' ),
			'new_item_name'              => __( 'New Category Name', 'theme_support_hash' ),
			'add_new_item'               => __( 'Add New Category', 'theme_support_hash' ),
			'edit_item'                  => __( 'Edit Category', 'theme_support_hash' ),
			'update_item'                => __( 'Update Category', 'theme_support_hash' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'theme_support_hash' ),
			'search_items'               => __( 'Search Categories', 'theme_support_hash' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'theme_support_hash' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'theme_support_hash' ),
		);
	
		$rewrite = array(
			'slug'                       => $this->sponsor_cat_slug,
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy('sponsor_category', 'sh_sponsor', $args );
		
		$labels = array(
			'name'                       => _x( 'Donors Type', 'Donors Type', SH_NAME ),
			'singular_name'              => _x( 'Donors Type', 'Donors Type', SH_NAME ),
			'menu_name'                  => __( 'Donors Type', 'theme_support_hash' ),
			'all_items'                  => __( 'All Donors', 'theme_support_hash' ),
			'parent_item'                => __( 'Parent Donors', 'theme_support_hash' ),
			'parent_item_colon'          => __( 'Parent Donors:', 'theme_support_hash' ),
			'new_item_name'              => __( 'New Donor Type', 'theme_support_hash' ),
			'add_new_item'               => __( 'Add New Donor Type', 'theme_support_hash' ),
			'edit_item'                  => __( 'Edit Donor Type', 'theme_support_hash' ),
			'update_item'                => __( 'Update Donor Type', 'theme_support_hash' ),
			'separate_items_with_commas' => __( 'Separate Donor Types with commas', 'theme_support_hash' ),
			'search_items'               => __( 'Search Donor Types', 'theme_support_hash' ),
			'add_or_remove_items'        => __( 'Add or remove Donor Types', 'theme_support_hash' ),
			'choose_from_most_used'      => __( 'Choose from the most used Donor Types', 'theme_support_hash' ),
		);
	
		$rewrite = array(
			'slug'                       => $this->donors_type_cat_slug,
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy( 'donors_type' , 'sh_donors' , $args );
		
		
	}
}