<?php
/*
Plugin Name: Theme Support Hash
Plugin URI: http://themeforest.net/user/WowThemes
Description: This plugin is compatible with all Wowthemes wordpress themes. 
Author: Shahbaz Ahmed
Author URI: http://wow-themes.com
Version: 1.0.3
Text Domain: SH_NAME
*/
if( !defined( 'SH_TH_ROOT' ) ) define('SH_TH_ROOT', plugin_dir_path( __FILE__ ));
if( !defined( 'SH_TH_URL' ) ) define( 'SH_TH_URL', plugins_url( '', __FILE__ ) );
if( !defined( 'SH_NAME' ) ) define( 'SH_NAME', 'wp_hash' );


add_action( 'plugins_loaded', 'hash_wow_themes_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function hash_wow_themes_load_textdomain() {

  load_plugin_textdomain( 'theme_support_hash', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' ); 
}

include_once( 'includes/loader.php' );

if(!function_exists('sh_shortcode_setup')){
    function sh_shortcode_setup($param1, $param2){
        add_shortcode($param1, $param2);
    }
}

