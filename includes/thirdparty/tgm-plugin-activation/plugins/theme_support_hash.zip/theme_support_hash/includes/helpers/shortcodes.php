<?php
class SH_Shortcodes
{
	public $keys;
	protected $base = '';
	protected $_dir = '';
	protected $_s_dir = '';
	
	
	function __construct()
	{
		//add_action('init', array( $this, 'add' ) );
		$this->add();
		
		$this->_dir = get_template_directory();
		$this->_s_dir = get_stylesheet_directory();
		
	}
	
	
	function add()
	{
		
		$this->keys = include( SH_TH_ROOT.'includes/resource/shortcodes.php');
		
		foreach ($this->keys as $key => $value) {
			
			add_shortcode( $key, array($this, 'add_shortcode'));
			if( function_exists('vc_map') ) vc_map( $value );
		}
	}

	function add_shortcode( $atts, $contents = null, $tag )
	{
		//echo $tag;exit;
		$tag_attr = HASH_WSH()->set(HASH_WSH()->set($this->keys, $tag), 'params' );
		
		$vars = array();

		if( $tag_attr )
		foreach( $tag_attr as $k => $v )
		{
			$vars[HASH_WSH()->set($v, 'param_name')] = '';//HASH_WSH()->set($v, 'value');
		}

		extract( shortcode_atts( $vars, $atts ) );
		
		ob_start();
		
		$file = locate_template('includes/modules/shortcodes/'.str_replace('sh_', '', $tag).'.php');

		
		if($file && file_exists($file) ) 
		include( $file );

		return ob_get_clean();

	}
	
	
	function excerpt( $str, $len = 35 )
	{
		return sh_trim( $str , $len );
	}
	
}
?>