<?php
$theme_option = get_option(SH_NAME.'_theme_options') ; 
$team_slug = hash_wow_sh_set($theme_option , 'team_permalink' , 'team') ;
$portfolio_slug = hash_wow_sh_set($theme_option , 'portfolio_permalink' , 'portfolio') ;
$services_slug = hash_wow_sh_set($theme_option , 'services_permalink' , 'services') ;
//$gallery_slug = hash_wow_sh_set($theme_option , 'galleries_permalink' , 'galleries') ;
$causes_slug = hash_wow_sh_set($theme_option , 'causes_permalink' , 'causes') ;
//$donate_slug = hash_wow_sh_set($theme_option , 'donate_permalink' , 'donate') ;
$donors_slug = hash_wow_sh_set($theme_option , 'donors_permalink' , 'donors') ;
$sponsor_slug = hash_wow_sh_set($theme_option , 'sponsor_permalink' , 'sponsor') ;

//$testimonial_slug = hash_wow_sh_set($theme_option , 'testimonial_permalink' , 'testimonial') ;
//$faqs_slug = hash_wow_sh_set($theme_option , 'faqs_permalink' , 'faqs') ;
$options = array();

$options['sh_team'] = array(
								'labels' => array(__('Member', 'theme_support_hash'), __('Member', 'theme_support_hash')),
								'slug' => $team_slug ,
								'label_args' => array('menu_name' => __('Teams', 'theme_support_hash')),
								'supports' => array( 'title', 'editor' , 'thumbnail'),
								'label' => __('Member', 'theme_support_hash'),
								'args'=>array(
											'menu_icon'=>'dashicons-groups' , 
											'taxonomies'=>array('team_category')
								)
							);
/*$options['sh_donors'] = array(
								'labels' => array(__('Donor', 'theme_support_hash'), __('Donor', 'theme_support_hash')),
								'slug' => $donors_slug ,
								'label_args' => array('menu_name' => __('Donors', 'theme_support_hash')),
								'supports' => array( 'title', 'editor' , 'thumbnail'),
								'label' => __('Donor', 'theme_support_hash'),
								'args'=>array(
											'menu_icon'=>'dashicons-groups', 
											'taxonomies'=>array('donors_category', 'donors_type')
								)
							);
$options['sh_portfolio'] = array(
								'labels' => array(__('Portfolio', 'theme_support_hash'), __('Portfolio', 'theme_support_hash')),
								'slug' => $portfolio_slug ,
								'label_args' => array('menu_name' => __('Portfolio', 'theme_support_hash')),
								'supports' => array( 'title', 'editor' , 'thumbnail'),
								'label' => __('Portfolio', 'theme_support_hash'),
								'args'=>array(
											'menu_icon'=>'dashicons-slides' , 
											'taxonomies'=>array('portfolio_category')
								)
							);
$options['sh_services'] = array(
								'labels' => array(__('Service', 'theme_support_hash'), __('Service', 'theme_support_hash')),
								'slug' => $services_slug ,
								'label_args' => array('menu_name' => __('Services', 'theme_support_hash')),
								'supports' => array( 'title' , 'editor' , 'thumbnail' ),
								'label' => __('Service', 'theme_support_hash'),
								'args'=>array(
										'menu_icon'=>'dashicons-slides' , 
										'taxonomies'=>array('services_category')
								)
							);*/
/*$options['sh_gallery'] = array(
								'labels' => array(__('Gallery', 'theme_support_hash'), __('Gallery', 'theme_support_hash')),
								'slug' => $gallery_slug ,
								'label_args' => array('menu_name' => __('Galleries', 'theme_support_hash')),
								'supports' => array( 'title' , 'editor' , 'thumbnail' ),
								'label' => __('Gallery', 'theme_support_hash'),
								'args'=>array(
										'menu_icon'=>'dashicons-slides' , 
										'taxonomies'=>array('gallery_category')
								)
							);*/
/*$options['sh_causes'] = array(
								'labels' => array(__('Causes', 'theme_support_hash'), __('Causes', 'theme_support_hash')),
								'slug' => $causes_slug ,
								'label_args' => array('menu_name' => __('Causes', 'theme_support_hash')),
								'supports' => array( 'title' , 'editor' , 'thumbnail' ),
								'label' => __('Causes', 'theme_support_hash'),
								'args'=>array(
										'menu_icon'=>'dashicons-slides' , 
										'taxonomies'=>array('causes_category')
								)
							);*/
							
/*$options['sh_donate'] = array(
								'labels' => array(__('Donate', 'theme_support_hash'), __('Donate', 'theme_support_hash')),
								'slug' => $donate_slug ,
								'label_args' => array('menu_name' => __('Donate', 'theme_support_hash')),
								'supports' => array( 'title' , 'editor' , 'thumbnail' ),
								'label' => __('Donate', 'theme_support_hash'),
								'args'=>array(
										'menu_icon'=>'dashicons-slides' , 
										'taxonomies'=>array('donate_category')
								)
							);*/
/*$options['sh_sponsor'] = array(
								'labels' => array(__('Sponsor', 'theme_support_hash'), __('Sponsor', 'theme_support_hash')),
								'slug' => $sponsor_slug ,
								'label_args' => array('menu_name' => __('Sponsor', 'theme_support_hash')),
								'supports' => array( 'title' , 'editor' , 'thumbnail' ),
								'label' => __('Sponsor', 'theme_support_hash'),
								'args'=>array(
										'menu_icon'=>'dashicons-slides' , 
										'taxonomies'=>array('sponsor_category')
								)
							);*/							
