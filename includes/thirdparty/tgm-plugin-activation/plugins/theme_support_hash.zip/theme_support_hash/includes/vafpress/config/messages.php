<?php

return array(

	////////////////////////////////////////
	// Localized JS Message Configuration //
	////////////////////////////////////////

	/**
	 * Validation Messages
	 */
	'validation' => array(
		'alphabet'     => __('Value needs to be Alphabet', 'theme_support_hash'),
		'alphanumeric' => __('Value needs to be Alphanumeric', 'theme_support_hash'),
		'numeric'      => __('Value needs to be Numeric', 'theme_support_hash'),
		'email'        => __('Value needs to be Valid Email', 'theme_support_hash'),
		'url'          => __('Value needs to be Valid URL', 'theme_support_hash'),
		'maxlength'    => __('Length needs to be less than {0} characters', 'theme_support_hash'),
		'minlength'    => __('Length needs to be more than {0} characters', 'theme_support_hash'),
		'maxselected'  => __('Select no more than {0} items', 'theme_support_hash'),
		'minselected'  => __('Select at least {0} items', 'theme_support_hash'),
		'required'     => __('This is required', 'theme_support_hash'),
	),

	/**
	 * Import / Export Messages
	 */
	'util' => array(
		'import_success'    => __('Import succeed, option page will be refreshed..', 'theme_support_hash'),
		'import_failed'     => __('Import failed', 'theme_support_hash'),
		'export_success'    => __('Export succeed, copy the JSON formatted options', 'theme_support_hash'),
		'export_failed'     => __('Export failed', 'theme_support_hash'),
		'restore_success'   => __('Restoration succeed, option page will be refreshed..', 'theme_support_hash'),
		'restore_nochanges' => __('Options identical to default', 'theme_support_hash'),
		'restore_failed'    => __('Restoration failed', 'theme_support_hash'),
	),

	/**
	 * Control Fields String
	 */
	'control' => array(
		// select2 select box
		'select2_placeholder' => __('Select option(s)', 'theme_support_hash'),
		// fontawesome chooser
		'fac_placeholder'     => __('Select an Icon', 'theme_support_hash'),
	),

);

/**
 * EOF
 */