<?php
class SH_Ajax
{
	
	function __construct()
	{
		add_action( 'wp_ajax__sh_ajax_callback', array( $this, 'ajax_handler' ) );
		add_action( 'wp_ajax_nopriv__sh_ajax_callback', array( $this, 'ajax_handler' ) );
	}
	
	function ajax_handler()
	{
		$method = hash_wow_sh_set( $_REQUEST, 'subaction' );
		if( method_exists( $this, $method ) ) $this->$method();
		
		exit;
	}
	
	function tweets()
	{
		if( !class_exists( 'Codebird' ) ) include_once( 'codebird.php' );
		$cb = new Codebird;
		$method = hash_wow_sh_set( $_POST, 'method' );
		
		$theme_options = HASH_WSH()->option();
		//printr($theme_options);
		$api = hash_wow_sh_set($theme_options, 'twitter_api');
		$api_secret = hash_wow_sh_set($theme_options, 'twitter_api_secret');
		$token = hash_wow_sh_set($theme_options, 'twitter_token');
		$token_secret = hash_wow_sh_set($theme_options, 'twitter_token_Secret');
		if( !$api && $api_secret ) 
		{ 
			_e('Please provide tiwtter api information to fetch feed', 'theme_support_hash');exit;
		}
		$cb->setConsumerKey($api, $api_secret);
		$cb->setToken($token, $token_secret);
		
		$return = array();
		
		$reply = (array) $cb->statuses_userTimeline(array('count'=>hash_wow_sh_set( $_REQUEST, 'num' ), 'screen_name'=>hash_wow_sh_set($_REQUEST, 'id')));
		if( isset( $reply['httpstatus'] ) ) unset( $reply['httpstatus'] );
		
		foreach( $reply as $k => $v ){
			
			//if( $k == 'httpstatus' ) continue;
			$time = human_time_diff( strtotime( hash_wow_sh_set( $v, 'created_at') ), current_time('timestamp') ) . __(' ago', 'theme_support_hash');
			$text = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank">$1</a>', hash_wow_sh_set( $v, 'text'));
			if($_REQUEST['template'] === 'lead' )
			{
				echo '<i class="fa fa-twitter"></i>'.$text.' <a href="#"> '.$time.'</a>' ;
			}
			elseif( $_REQUEST['template'] == 'owl' )
			{
				$return[] = '<div class="item">
							  <div class="row">
								<div class="col-md-11">
								  <div class="tweet-time pull-left white">
									<i class="fa fa-twitter"></i><span>'.__(' about ', 'theme_support_hash').$time.'</span>
								  </div>
								  <div class="twitter-tweet pull-right white">  
									<p class="white">'.$text.' </p>
								  </div>
								</div>
								<div class="col-md-1"></div>
							  </div>
							</div>';
			}
			else {
				echo 
				'<li><span></span><p>'.$text.' <a href="#">'.__(' about ', 'theme_support_hash').$time.'</a></p></li>';
			}
		}
		//_wow_themes_printr($return);
		if( $return ) echo json_encode( $return );
	}
	
	function contact_form_submit()
	{
		if( !count( $_POST ) ) return;
	
		_load_plugins_class( 'validation', 'helpers', true );
		$t = $GLOBALS['_sh_base'];//printr($t);
		$settings = $t->option();
		
		$post_test = hash_wow_sh_set( $_POST, 'test' );
		$rec_email  = sanitize_email( $post_test ) ? sanitize_email( $post_test ) : _sh_generate_salt( $post_test, true );
		/** set validation rules for contact form */
		$t->validation->set_rules('contact_name','<strong>'.__('Name', 'theme_support_hash').'</strong>', 'required|min_length[4]|max_lenth[30]');
		
		//$t->validation->set_rules('aplus_l_name','<strong>'.__('Last Name', 'theme_support_hash').'</strong>', 'required|min_length[4]|max_lenth[30]');
		$t->validation->set_rules('contact_email','<strong>'.__('Email', 'theme_support_hash').'</strong>', 'required|valid_email');
		
		$t->validation->set_rules('contact_website','<strong>'.__('Website', 'theme_support_hash').'</strong>');
		$t->validation->set_rules('contact_subject','<strong>'.__('Subject', 'theme_support_hash').'</strong>', 'min_length[5]');
		
		$t->validation->set_rules('contact_message','<strong>'.__('Message', 'theme_support_hash').'</strong>', 'required|min_length[5]');
		if( hash_wow_sh_set($settings, 'contact_captcha_status'))
		{
			include_once( get_template_directory().'/includes/thirdparty/recaptchalib.php');
			$privatekey = hash_wow_sh_set($settings, 'recaptcha_private');
			
			$resp = recaptcha_check_answer ($privatekey,
                                 $_SERVER["REMOTE_ADDR"],
                                 $_POST["recaptcha_challenge_field"],
                                 $_POST["recaptcha_response_field"]);
			
			if( !$resp->is_valid )
			{
					$t->validation->_error_array['captcha'] = __('Invalid captcha entered, please try again.', 'theme_support_hash');
			}
	
		}
		$messages = '';
		if($t->validation->run() !== FALSE && empty($t->validation->_error_array))
		{
			$name = $t->validation->post('contact_name');
			$email = $t->validation->post('contact_email');
			
			$message = __("Contact Name:\t", 'theme_support_hash').$name."\r\n";
			$message .= "\r\n".__("Contact Website:\t", 'theme_support_hash').$t->validation->post('contact_website')."\r\n";
			$message .= "\r\n".__("Contact Subject:\t", 'theme_support_hash').hash_wow_sh_set( $_POST, 'contact_subject')."\r\n";
			
			$message .= "\r\n".$t->validation->post('contact_message'); 
	
			$contact_to = sanitize_email($rec_email) ? $rec_email : get_option('admin_email');
			
			$headers = 'From: '.$name.' <'.$email.'>' . "\r\n";
			wp_mail($contact_to, sprintf(__('Contact Us Message from %s', 'theme_support_hash'), get_bloginfo('name') ), $message, $headers);
	
			echo "<fieldset>";
			echo "<div id='success_page' class='alert alert-success'>";
			echo "<h1>".__('Email Sent Successfully.', 'theme_support_hash')."</h1>";
			echo "<p>".sprintf(__("Thank you <strong>%s</strong>, your message has been submitted to us.", 'theme_support_hash'), $name)."</p>";
			echo "</div>";
			echo "</fieldset>";
			exit;
		
		}else
		{
	
			 if( is_array( $t->validation->_error_array ) )
			 {
				 foreach( $t->validation->_error_array as $msg )
				 {
					 $messages .= '<div class="alert alert-danger">'.__('Error! ', 'theme_support_hash').$msg.'</div>';
				 }
			}
	
		}
	
		echo $messages;exit;
	}
	
	//register events
	function register_event_form_submit()
	{
		if( !count( $_POST ) ) return;
	
		_load_plugins_class( 'validation', 'helpers', true );
		$t = $GLOBALS['_sh_base'];//printr($t);
		$settings = $t->option();
		
		$post_test = hash_wow_sh_set( $_POST, 'test' );
		$rec_email  = sanitize_email( $post_test ) ? sanitize_email( $post_test ) : _sh_generate_salt( $post_test, true );
		/** set validation rules for contact form */
		$t->validation->set_rules('event_name','<strong>'.__('Name', 'theme_support_hash').'</strong>', 'required|min_length[4]|max_lenth[30]');
		
		//$t->validation->set_rules('aplus_l_name','<strong>'.__('Last Name', 'theme_support_hash').'</strong>', 'required|min_length[4]|max_lenth[30]');
		$t->validation->set_rules('event_email','<strong>'.__('Email', 'theme_support_hash').'</strong>', 'required|valid_email');
		
		$t->validation->set_rules('event_phone','<strong>'.__('Event Phone', 'theme_support_hash').'</strong>');
		$t->validation->set_rules('event_attended','<strong>'.__('Event Attended', 'theme_support_hash').'</strong>');
		
		$t->validation->set_rules('book_sheet','<strong>'.__('Book Sheet', 'theme_support_hash').'</strong>');
		if( hash_wow_sh_set($settings, 'contact_captcha_status'))
		{
			include_once( get_template_directory().'/includes/thirdparty/recaptchalib.php');
			$privatekey = hash_wow_sh_set($settings, 'recaptcha_private');
			
			$resp = recaptcha_check_answer ($privatekey,
                                 $_SERVER["REMOTE_ADDR"],
                                 $_POST["recaptcha_challenge_field"],
                                 $_POST["recaptcha_response_field"]);
			
			if( !$resp->is_valid )
			{
					$t->validation->_error_array['captcha'] = __('Invalid captcha entered, please try again.', 'theme_support_hash');
			}
	
		}
		$messages = '';
		if($t->validation->run() !== FALSE && empty($t->validation->_error_array))
		{
			$name = $t->validation->post('event_name');
			$email = $t->validation->post('event_email');
			$phone = $t->validation->post('event_phone');
			$event_attended = $t->validation->post('event_attended');
			$book_sheet = $t->validation->post('book_sheet');
			
			$message = __("Name:\t", 'theme_support_hash').$name."\r\n";
			$message .= __("Phone:\t", 'theme_support_hash').$phone."\r\n";
			$message .= __("Event Attended:\t", 'theme_support_hash').$event_attended."\r\n";
			$message .= __("Event:\t", 'theme_support_hash').$book_sheet."\r\n";
			
			//$message .= "\r\n".__("Contact Website:\t", 'theme_support_hash').$t->validation->post('contact_website')."\r\n";
			//$message .= "\r\n".__("Contact Subject:\t", 'theme_support_hash').hash_wow_sh_set( $_POST, 'contact_subject')."\r\n";
			
			//$message .= "\r\n".$t->validation->post('contact_message'); 
	
			$contact_to = get_option('admin_email');
			
			$headers = 'From: '.$name.' <'.$email.'>' . "\r\n";
			wp_mail($contact_to, sprintf(__('Event Message from %s', 'theme_support_hash'), get_bloginfo('name') ), $message, $headers);
	
			echo "<fieldset>";
			echo "<div id='success_page' class='alert alert-success'>";
			echo "<h1>".__('Email Sent Successfully.', 'theme_support_hash')."</h1>";
			echo "<p>".sprintf(__("Thank you <strong>%s</strong>, your message has been submitted to us.", 'theme_support_hash'), $name)."</p>";
			echo "</div>";
			echo "</fieldset>";
			exit;
		
		}else
		{
	
			 if( is_array( $t->validation->_error_array ) )
			 {
				 foreach( $t->validation->_error_array as $msg )
				 {
					 $messages .= '<div class="alert alert-danger">'.__('Error! ', 'theme_support_hash').$msg.'</div>';
				 }
			}
	
		}
	
		echo $messages;exit;
	}
		
	function wishlist()
	{
		global $current_user;
      	get_currentuserinfo();
			
		if( is_user_logged_in() ){
			
			$meta = (array)get_user_meta( $current_user->ID, '_ja_product_wishlist', true );
			$data_id = hash_wow_sh_set( $_POST, 'data_id' );
			if( $meta && is_array( $meta ) ){
				if( in_array( $data_id, $meta ) ){
					exit(json_encode(array('code'=>'exists', 'msg'=>__('You have already added this product to wish list', 'theme_support_hash' ) ) ) );
				}
				$newmeta = array_merge( array( hash_wow_sh_set( $_POST, 'data_id' ) ), $meta );
				update_user_meta( $current_user->ID, '_ja_product_wishlist', array_unique($newmeta) );
				exit(json_encode(array('code'=>'success', 'msg'=>__('Product successfully added to wishlist', 'theme_support_hash' ) ) ) );
			}else{
				exit(json_encode(array('code'=>'fail', 'msg'=>__('There is an error edding wishlist', 'theme_support_hash' ) ) ) );
			}
		}
		else exit(json_encode(array('code'=>'fail', 'msg'=>__('Please login first to add the product to your wishlist', 'theme_support_hash' ) ) ) );
	}
	
	function wishlist_del()
	{
		global $current_user;
      	get_currentuserinfo();
			
		if( is_user_logged_in() ){
			
			$meta = get_user_meta( $current_user->ID, '_ja_product_wishlist', true );
			$data_id = hash_wow_sh_set( $_POST, 'data_id' );
			if( $meta && is_array( $meta ) ){
				$searched = array_search( $data_id, $meta );
				if( isset($meta[$searched]) ){
					unset( $meta[$searched] );
					update_user_meta( $current_user->ID, '_ja_product_wishlist', array_unique($meta) );
					exit(json_encode(array('code'=>'del', 'msg'=>__('Product is successfully deleted from wishlist', 'theme_support_hash' ) ) ) );
				}else exit(json_encode(array('code'=>'fail', 'msg'=>__('Unable to find this product into wishlist', 'theme_support_hash' ) ) ) );
			}else{
				update_user_meta( $current_user->ID, '_ja_product_wishlist', array( hash_wow_sh_set( $_POST, 'data_id' ) ) );
				exit(json_encode(array('code'=>'fail', 'msg'=>__('Unable to retrieve your wishlist', 'theme_support_hash' ) ) ) );
			}
		}
		else exit(json_encode(array('code'=>'fail', 'msg'=>__('Please login first to add/delete product in your wishlist', 'theme_support_hash' ) ) ) );
	}
	
	function download_rating()
	{
		$ip = $_SERVER['REMOTE_ADDR'];
		extract( $_POST );
		
		$meta = get_post_meta( $post_id, '_download_rating', true );
		
		if( !hash_wow_sh_set( $meta, $ip ) )
		{
			$meta[$ip] = $value;
			
			update_post_meta( $post_id, '_download_rating', $meta );
			
			$meta = get_post_meta( $post_id, '_download_rating', true );
			
			$count = count( $meta ) ? count( $meta ) : 1;
			$evg = array_sum((array)$meta) / $count;
			update_post_meta( $post_id, '_post_rating_avg', $evg );
			
			echo 'success';exit;
		}
		
		exit( 'failed' );
	}
	
	
	function courses_filter()
	{
		$view = hash_wow_sh_set( $_POST, 'view' );
		
		//if( $view == 'list' ) get_template_part( 'includes/modules/courses_list');
		//else get_template_part( 'includes/modules/courses_grid');
		get_template_part( 'includes/modules/courses/course' );
	}
	
	function register_user() 
	{
		$res = sh_register_user($_POST);
		
		echo json_encode($res);exit;
	}
	
	function login_user()
	{
		$user = wp_signon( $_POST, false );
		
		if( ! is_wp_error( $user ) && isset( $user->ID ) ) {
			//wp_generate_auth_cookie( $user->ID );
			echo json_encode( array('type'=>'success', 'msg' => '' ) );
			return;
		}else {
			
			echo json_encode( array('type'=>'error', 'msg' => '<div class="alert-danger">'.$user->get_error_message().'</div>' ) );
			
		}
	}
}