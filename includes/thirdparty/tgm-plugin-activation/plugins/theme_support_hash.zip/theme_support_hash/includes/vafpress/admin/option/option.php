<?php

if (!defined('ABSPATH')) {
    die;
}
// Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings = array(
    'menu_title' => esc_html__('Theme Options', 'hash'),
    'menu_type' => 'add_theme_page',
    'menu_slug' => SH_NAME . '_options',
    'ajax_save' => false,
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options = array();


// ------------------------------
// GENERAL SETTINGS   -
// ------------------------------
$options[] = array(
    'name' => 'gen_settings',
    'title' => 'GENERAL SETTINGS',
    'icon' => 'fa fa-cogs',
    'sections' => array(
        // -----------------------------
        // begin: General Settings         -
        // -----------------------------
        array(
            'name' => 'general_settings',
            'title' => 'General Settings',
            'icon' => 'fa fa-cog',
            // begin: fields
            'fields' => array(
                // begin: color scheme heading
                array(
                    'type' => 'heading',
                    'content' => 'Color Scheme',
                ),
                array(
                    'id' => 'color_schemes',
                    'type' => 'color_picker',
                    'title' => 'Color Scheme',
                    'desc' => 'Choose the Custom color scheme for the theme.',
                    'default' => 'rgba(0, 0, 255, 0.25)',
                ),
                array(
                    'type' => 'heading',
                    'content' => 'Boxed Version Settings',
                ),
                array(
                    'type' => 'toggle',
                    'name' => 'rtl',
                    'label' => __( 'Enable RTL', 'theme_support_multi' ),
                    'description' => __( 'Enable / Disable rtl ( Right to Left ).', 'theme_support_multi' ),
                    'default' => 0,
                    
                ),
                // begin: Boxed Version Settings
                array(
                    'type' => 'heading',
                    'content' => 'Boxed Version Settings',
                ),
                array(
                    'id' => 'boxed_version_settings',
                    'type' => 'switcher',
                    'title' => 'Boxed Version Settings',
                    'desc' => 'This section contain the information about boxed version settings.',
                    'label' => 'Yes, Please do it.',
                ),
                // begin: color Twitter Settings
                array(
                    'type' => 'heading',
                    'content' => 'Twitter Settings',
                ),
                array(
                    'id' => 'twitter_api',
                    'type' => 'text',
                    'title' => 'API Key',
                    'desc' => 'To get the API keys visist <a href="http://apps.twitter.com">Twitter APPs</a>',
                    'attributes' => array(
                        'style' => 'width: 604px; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'twitter_api_secret',
                    'type' => 'text',
                    'title' => 'API Secret key',
                    'desc' => 'Enter api secret key.',
                    'attributes' => array(
                        'style' => 'width: 604px; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'twitter_token',
                    'type' => 'text',
                    'title' => 'Token',
                    'desc' => 'Enter generated token.',
                    'attributes' => array(
                        'style' => 'width: 604px; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'twitter_token_secret',
                    'type' => 'text',
                    'title' => 'Token secret key',
                    'desc' => 'enter token secret.',
                    'attributes' => array(
                        'style' => 'width: 604px; height: 40px;'
                    ),
                ),
                // begin: Purchase Information
                array(
                    'type' => 'heading',
                    'content' => 'Purchase Information',
                ),
                array(
                    'id' => 'purchase_information',
                    'type' => 'text',
                    'title' => 'Purchase Information',
                    'desc' => 'To get the auto theme updates provide purchase information.',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'sh_purchase_code',
                    'type' => 'text',
                    'title' => 'Purchase Code',
                    'desc' => 'To find the purchase code to TF downloads tab click on Download then choose "License and Purchase code.',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
            ), // end: fields
        ), // end: General Settings
        // -----------------------------
        // begin: Header Settings     -
        // -----------------------------
        array(
            'name' => 'header_settings',
            'title' => 'Header Settings',
            'icon' => 'fa fa-hand-o-right',
            'fields' => array(
                // begin: Favicon

                array(
                    'type' => 'heading',
                    'content' => 'Header Settings',
                ),
                array(
                    'id' => 'site_favicon',
                    'type' => 'upload',
                    'title' => 'Upload the favicon, should be 16x16',
                    'attributes' => array(
                        'style' => 'width: 485px;'
                    ),
                    'settings' => array(
                        'button_title' => 'Upload Favicon',
                        'frame_title' => 'Choose a image',
                        'insert_title' => 'Use this image',
                    ),
                ),
                array(
                    'id' => 'logo_type',
                    'type' => 'upload',
                    'title' => 'Upload the Logo',
                    'attributes' => array(
                        'style' => 'width: 502px;'
                    ),
                    'settings' => array(
                        'button_title' => 'Upload Logo',
                        'frame_title' => 'Choose a image',
                        'insert_title' => 'Use this image',
                    ),
                ),
                array(
                    'id' => 'header_add',
                    'type' => 'upload',
                    'title' => 'Upload Header Add',
                    'disc' => 'Add Size Should be 728x90',
                    'attributes' => array(
                        'style' => 'width: 502px;'
                    ),
                    'settings' => array(
                        'button_title' => 'Upload Add',
                        'frame_title' => 'Choose a image',
                        'insert_title' => 'Use this image',
                    ),
                ),
                array(
                    'id' => 'add_url',
                    'type' => 'text',
                    'title' => 'Add URL',
                    'desc' => 'Enter Header Add URL',
                    'default' => '',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                /* 		array(
                  'id'    => 'searchbox',
                  'type'  => 'switcher',
                  'title' => 'Show Search Box',
                  'desc'  => 'Show or hide search box in header.',
                  'label' => 'Yes, Please do it.',
                  ), */
                array(
                    'id' => 'header_css',
                    'type' => 'textarea',
                    'title' => 'Header CSS',
                    'desc' => 'Write your custom css to include in header.',
                    'default' => '',
                ),
            ),
        ), // end: header settings
        // -----------------------------
        // begin: Footer Settings     -
        // -----------------------------
        array(
            'name' => 'footer_settings',
            'title' => 'Footer Settings',
            'icon' => 'fa fa-hand-o-right',
            'fields' => array(
                // begin: Footer Settings

                array(
                    'type' => 'heading',
                    'content' => 'Footer Settings',
                ),
                array(
                    'id' => 'show_footer',
                    'type' => 'switcher',
                    'title' => 'Show/Hide whole footer',
                    'desc' => 'Show or hide whole footer.',
                    'label' => 'Yes, Please do it.',
                ),
                /* 		array(
                  'id'      => 'footer_bg',
                  'attributes' => array(
                  'style'    => 'width: 536px;'
                  ),
                  'type'    => 'upload',
                  'title'   => 'Footer Background',
                  'desc'    => 'choose the Footer Background.',
                  'help'    => 'choose the Footer Background.',
                  ), */
                array(
                    'id' => 'footer_address',
                    'type' => 'textarea',
                    'title' => 'Footer Address',
                    'desc' => 'Enter Address to show on footer.',
                    'default' => '123 South corner street, Melbourne.',
                ),
                array(
                    'id' => 'footer_phone',
                    'type' => 'text',
                    'title' => 'Footer Phone',
                    'desc' => 'Enter Phone to show on footer.',
                    'default' => '+61 012 345 6789',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'footer_email',
                    'type' => 'text',
                    'title' => 'Footer Email',
                    'desc' => 'Enter Email to show on footer.',
                    'default' => 'info@agile.com',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'copy_right',
                    'type' => 'textarea',
                    'title' => 'Copy Right Text',
                    'desc' => 'Enter the Copy Right Text.',
                    'default' => '© COPY RIGHTS 2015 All Rights Reserved. ',
                ),
            ),
        ), // end: footer settings
        // -----------------------------
        // begin: Permalinks Settings       -
        // -----------------------------
        array(
            'name' => 'permalinks_settings',
            'title' => 'Permalinks Settings',
            'icon' => 'fa fa-link',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => 'Post Type Permalinks',
                ),
                array(
                    'id' => 'team_permalink',
                    'type' => 'text',
                    'title' => 'Team Permalink',
                    'desc' => 'Enter Slug for Team Post Type.',
                    'default' => '',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'services_permalink',
                    'type' => 'text',
                    'title' => 'Services Permalink',
                    'desc' => 'Enter Slug for Services Post Type.',
                    'default' => '',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'projects_permalink',
                    'type' => 'text',
                    'title' => 'Projects Permalink',
                    'desc' => 'Enter Permalink for Projects Post Type.',
                    'default' => '',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'testimonial_permalink',
                    'type' => 'text',
                    'title' => 'Testimonial Permalink',
                    'desc' => 'Enter Permalink for Testimonial Post Type.',
                    'default' => '',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'type' => 'heading',
                    'content' => 'Category Permalinks',
                ),
                array(
                    'id' => 'team_category_permalink',
                    'type' => 'text',
                    'title' => 'Team Category Permalink',
                    'desc' => 'Enter Slug for Team Taxonomy.',
                    'default' => '',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'services_category_permalink',
                    'type' => 'text',
                    'title' => 'Services Category Permalink',
                    'desc' => 'Enter Slug for Services Taxonomy.',
                    'default' => '',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'projects_category_permalink',
                    'type' => 'text',
                    'title' => 'Projects Category Permalink',
                    'desc' => 'Enter Permalink for Projects Taxonomy.',
                    'default' => '',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'testimonial_category_permalink',
                    'type' => 'text',
                    'title' => 'Testimonial Category Permalink',
                    'desc' => 'Enter Permalink for Testimonial Taxonomy.',
                    'default' => '',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
            ),
        ), // end: other options
    )
);

// ------------------------------
// a seperator                  -
// ------------------------------
// ------------------------------
// GENERAL SETTINGS   -
// ------------------------------
$options[] = array(
    'name' => 'page_settings',
    'title' => 'Page Settings',
    'icon' => 'fa fa-file',
    'sections' => array(
        // -----------------------------
        // begin: Blog Page Settings         -
        // -----------------------------
        array(
            'name' => 'blog_page_settings',
            'title' => 'Blog Page',
            'icon' => 'fa fa-cog',
            // begin: fields
            'fields' => array(
                // begin: color scheme heading
                array(
                    'type' => 'heading',
                    'content' => 'Blog Page Settings',
                ),
                array(
                    'id' => 'blog_page_sidebar',
                    'type' => 'select',
                    'title' => 'Select with Chosen',
                    'options' => agile_get_sidebars(true),
                    'default' => array(
                        '{{first}}'
                    )
                ),
                array(
                    'id' => 'blog_page_layout',
                    'type' => 'image_select',
                    'title' => 'Page Layout',
                    'options' => array(
                        'left' => SH_URL . '/includes/thirdparty/framework/assets/images/2cl.png',
                        'right' => SH_URL . '/includes/thirdparty/framework/assets/images/2cr.png',
                        'full' => SH_URL . '/includes/thirdparty/framework/assets/images/1col.png',
                    ),
                    'radio' => true,
                    'default' => 'full'
                ),
            ), // end: fields
        ), // end: General Settings
        // -----------------------------
        // begin: Search Page Settings         -
        // -----------------------------
        array(
            'name' => 'search_page_settings',
            'title' => 'Search Page',
            'icon' => 'fa fa-search',
            // begin: fields
            'fields' => array(
                // begin: color scheme heading
                array(
                    'type' => 'heading',
                    'content' => 'Search Page Settings',
                ),
                array(
                    'id' => 'search_page_sidebar',
                    'type' => 'select',
                    'title' => 'Select with Chosen',
                    'options' => array(
                        'data' => array(
                            'source' => 'function',
                            'value' => 'sh_get_sidebars_2'
                        ),
                    ),
                    'default' => array(
                        '{{first}}'
                    )
                ),
                array(
                    'id' => 'search_page_layout',
                    'type' => 'image_select',
                    'title' => 'Page Layout',
                    'options' => array(
                        'left' => SH_URL . '/includes/thirdparty/framework/assets/images/2cl.png',
                        'right' => SH_URL . '/includes/thirdparty/framework/assets/images/2cr.png',
                        'full' => SH_URL . '/includes/thirdparty/framework/assets/images/1col.png',
                    ),
                    'radio' => true,
                    'default' => 'full'
                ),
            ), // end: fields
        ), // end: General Settings
        // -----------------------------
        // begin: Archive Page Settings     -
        // -----------------------------
        array(
            'name' => 'archive_page_settings',
            'title' => 'Archive Page',
            'icon' => 'fa fa-archive',
            'fields' => array(
                // begin: Favicon

                array(
                    'type' => 'heading',
                    'content' => 'Header Settings',
                ),
                array(
                    'id' => 'search_page_sidebar',
                    'type' => 'select',
                    'title' => 'Sidebar',
                    'options' => array(
                        'data' => array(
                            array(
                                'source' => 'function',
                                'value' => 'sh_get_sidebars_2'
                            )
                        )
                    ),
                    'default' => array(
                        '{{first}}'
                    )
                ),
                array(
                    'id' => 'archive_page_layout',
                    'type' => 'image_select',
                    'title' => 'Page Layout',
                    'options' => array(
                        'left' => SH_URL . '/includes/thirdparty/framework/assets/images/2cl.png',
                        'right' => SH_URL . '/includes/thirdparty/framework/assets/images/2cr.png',
                        'full' => SH_URL . '/includes/thirdparty/framework/assets/images/1col.png',
                    ),
                    'radio' => true,
                    'default' => 'full'
                ),
            ),
        ), // end: Archive Page settings
        // -----------------------------
        // begin: Author Page Settings     -
        // -----------------------------
        array(
            'name' => 'author_page_settings',
            'title' => 'Author Page',
            'icon' => 'fa fa-user',
            'fields' => array(
                // begin: Footer Settings

                array(
                    'type' => 'heading',
                    'content' => 'Footer Settings',
                ),
                array(
                    'id' => 'author_page_sidebar',
                    'type' => 'select',
                    'title' => 'Select with Chosen',
                    'options' => array(
                        'data' => array(
                            array(
                                'source' => 'function',
                                'value' => 'sh_get_sidebars_2'
                            )
                        )
                    ),
                    'default' => array(
                        '{{first}}'
                    )
                ),
                array(
                    'id' => 'author_page_sidebar',
                    'type' => 'image_select',
                    'title' => 'Page Layout',
                    'options' => array(
                        'left' => SH_URL . '/includes/thirdparty/framework/assets/images/2cl.png',
                        'right' => SH_URL . '/includes/thirdparty/framework/assets/images/2cr.png',
                        'full' => SH_URL . '/includes/thirdparty/framework/assets/images/1col.png',
                    ),
                    'radio' => true,
                    'default' => 'full'
                ),
            ),
        ), // end: Author Page settings
        // -----------------------------
        // begin: 404 page Settings       -
        // -----------------------------
        array(
            'name' => '404_page_settings',
            'title' => '404 Page Settings',
            'icon' => 'fa fa-exclamation-triangle',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => '404 Page Settings',
                ),
                array(
                    'id' => '404_page_title',
                    'type' => 'text',
                    'title' => 'Page Title',
                    'desc' => 'Enter the Title you want to show on 404 page.',
                    'default' => '404 Page not Found',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => '404_page_text',
                    'type' => 'textarea',
                    'title' => '404 Page Text',
                    'desc' => 'Enter the Text you want to show on 404 page.',
                    'default' => '',
                ),
                array(
                    'id' => '404_page_bg',
                    'type' => 'upload',
                    'title' => 'Header Background  Image',
                    'desc' => 'Upload Image for 404 Page Background.',
                    'attributes' => array(
                        'style' => 'width: 81.9%;'
                    ),
                    'settings' => array(
                        'button_title' => 'Header Image',
                        'frame_title' => 'Choose a image',
                        'insert_title' => 'Use this image',
                    ),
                ),
            ),
        ), // end: other options
    )
);



// ------------------------------
// GENERAL SETTINGS   -
// ------------------------------
$options[] = array(
    'name' => 'sidebar_settings',
    'title' => 'Sidebar Settings',
    'icon' => 'fa fa-bars',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => 'Add Sidebar'
        ),
        array(
            'id' => 'dynamic_sidebar',
            'type' => 'group',
            'title' => 'Dynamic Sidebar',
            'button_title' => 'Add Dynamic Sidebar',
            'desc' => 'This section is used to add more dynamic sidebars.',
            'accordion_title' => 'Add New Field',
            'fields' => array(
                array(
                    'id' => 'sidebar_name',
                    'type' => 'text',
                    'title' => 'Sidebar Name',
                    'desc' => 'Add Sidebar From Here.',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
            )
        ), // end: group options
    ),
);



$options[] = array(
    'name' => 'social_media',
    'title' => 'Social Media',
    'icon' => 'fa fa-share-square',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => 'Add Social Media'
        ),
        array(
            'id' => 'social_media',
            'type' => 'group',
            'title' => 'Social Media',
            'button_title' => 'Add Social Media',
            'desc' => 'This section is used to add social media.',
            'accordion_title' => 'Social Media',
            'fields' => array(
                array(
                    'id' => 'hover_color',
                    'type' => 'color_picker',
                    'title' => 'Social media hover colour',
                    'desc' => 'Choose the Custom color for social media hover..',
                    'default' => 'rgba(0, 0, 255, 0.25)',
                ),
                array(
                    'id' => 'social_title',
                    'type' => 'text',
                    'title' => 'Title',
                    'desc' => 'Enter the title of the social media.',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'social_link',
                    'type' => 'text',
                    'title' => 'Link',
                    'desc' => 'Enter the Link for Social Media.',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'social_icon',
                    'type' => 'icon',
                    'title' => 'Icon',
                    'desc' => 'Choose Icon for Social Media.',
                ),
            )
        ), // end: group options
    ),
);



$options[] = array(
    'name' => 'font_settings',
    'title' => 'Font Settings',
    'icon' => 'fa fa-font',
    'sections' => array(
        array(
            'name' => 'font_settings',
            'title' => 'Font Settings',
            'icon' => 'fa fa-hand-o-right',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => 'Heading Font',
                ),
                array(
                    'id' => 'dummy_1',
                    'type' => 'notice',
                    'class' => 'info',
                    'content' => 'Done, this text option have something.',
                    'dependency' => array('dep_1', '!=', ''),
                ),
                // ------------------------------------
                // ------------------------------------
                array(
                    'id' => 'use_custom_font',
                    'type' => 'switcher',
                    'title' => 'Use Custom Font',
                    'desc' => 'Use custom font or not.',
                ),
                array(
                    'id' => 'dummy_2',
                    'type' => 'notice',
                    'class' => 'success',
                    'content' => 'You have Selected Custom Fonts!',
                    'dependency' => array('use_custom_font', '==', 'true'),
                ),
            ),
        ), // end: group options
        array(
            'name' => 'body_font_settings',
            'title' => 'Body Font',
            'icon' => 'fa fa-hand-o-right',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => 'Body Font',
                ),
                array(
                    'id' => 'dummy_1',
                    'type' => 'notice',
                    'class' => 'info',
                    'content' => 'Done, this text option have something.',
                    'dependency' => array('dep_1', '!=', ''),
                ),
                // ------------------------------------
                // ------------------------------------
                array(
                    'id' => 'body_custom_font',
                    'type' => 'switcher',
                    'title' => 'Use Custom Font',
                    'desc' => 'Use custom font or not.',
                ),
                array(
                    'id' => 'dummy_2',
                    'type' => 'notice',
                    'class' => 'success',
                    'content' => 'You have Selected Custom Body Fonts!',
                    'dependency' => array('body_custom_font', '==', 'true'),
                ),
            ),
        ), // end: group options
    ),
);



$options[] = array(
    'name' => 'brand_or_client',
    'title' => 'Clients',
    'icon' => 'fa fa-star',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => 'Add Clients'
        ),
        array(
            'id' => 'brand_or_client',
            'type' => 'group',
            'title' => 'Clients',
            'button_title' => 'Add More Clients',
            'desc' => 'Add as many clients as you want.',
            'accordion_title' => 'Clients',
            'fields' => array(
                array(
                    'id' => 'title',
                    'type' => 'text',
                    'title' => 'Name',
                    'desc' => 'Enter company name.',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'text',
                    'type' => 'textarea',
                    'title' => 'Client Description',
                    'desc' => 'Enter Client Description.',
                    'default' => '',
                ),
                array(
                    'id' => 'link',
                    'type' => 'text',
                    'title' => 'Link',
                    'desc' => 'Enter company website link.',
                    'attributes' => array(
                        'style' => 'width: 100%; height: 40px;'
                    ),
                ),
                array(
                    'id' => 'img',
                    'type' => 'upload',
                    'title' => 'Company Image',
                    'desc' => 'choose the client logo.',
                    'attributes' => array(
                        'style' => 'width: 71.9%;'
                    ),
                    'settings' => array(
                        'button_title' => 'Upload Image',
                        'frame_title' => 'Choose a image',
                        'insert_title' => 'Use this image',
                    ),
                ),
            )
        ), // end: group options
    ),
);



$options[] = array(
    'name' => 'instagram_settings',
    'title' => 'Instagram Settings',
    'icon' => 'fa fa-gift',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => 'Instagram Settings'
        ),
        array(
            'id' => 'client_id',
            'type' => 'text',
            'title' => 'Client ID',
            'desc' => 'Enter the client id.',
            'attributes' => array(
                'style' => 'width: 100%; height: 40px;'
            ),
        ),
        array(
            'id' => 'user_name',
            'type' => 'text',
            'title' => 'Enter instagram username',
            'desc' => 'Enter Instagram Username.',
            'attributes' => array(
                'style' => 'width: 100%; height: 40px;'
            ),
        ),
    ),
);



// ------------------------------
// backup                       -
// ------------------------------
$options[] = array(
    'name' => 'backup_section',
    'title' => 'Backup',
    'icon' => 'fa fa-shield',
    'fields' => array(
        array(
            'type' => 'notice',
            'class' => 'warning',
            'content' => 'You can save your current options. Download a Backup and Import.',
        ),
        array(
            'type' => 'backup',
        ),
    )
);

CSFramework::instance($settings, $options);
